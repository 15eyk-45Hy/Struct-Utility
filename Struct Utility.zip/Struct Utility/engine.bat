@echo off 
::     =================================
::       S   E   T   T   I   N   G   S   
::     =================================

set "ENGINE_ROOT_DIR=Struct Utility" 

set "TYPE.int=int"
set "TYPE.str=str"

chcp 65001 >nul

set "Version_Utility=1.0"

if /i "%~1"=="struct" goto :Create_Struct
if /i "%~1"=="new" goto :InitVar
if /i "%~1"=="namespace" goto :Resolve_Namespace

call "%~dp0ErrorProtocol.bat" "#001"

:Create_Struct
setlocal enabledelayedexpansion

set "OptMode=%~2"
set "Current_Name_Struct=%~3"

echo %~3 | findstr /r "[\\:%%^^!]" >nul 2>&1

if %errorlevel%==0 call "%~dp0ErrorProtocol.bat" "#008" "!Current_Name_Struct!"

set "counter_prop=0"

set "Current_DB_Struct=%~dp0DataBase-Structs\DataBase-Struct-!Current_Name_Struct!.meta"

set "del_curr_struct="
if exist "!Current_DB_Struct!" (
    if /i "!OptMode!"=="OptMode-true" (    
        exit /b
    ) else (
        set "del_curr_struct=1"
    )
)

:Struct_Loop

set "Current_Property=%~4"
 
if "!Current_Property!"=="" goto :Struct_Done

if not "!Current_Property!"=="!Current_Name_Struct!" (
    if not "!Current_Property!"==":struct" (

        set /a "counter_prop+=1"

        for /f "delims=: tokens=1,2" %%a in ("!Current_Property!") do (
            set "is_valid_type=!TYPE.%%a!"
            if not defined is_valid_type call "%~dp0ErrorProtocol.bat" "#006" "!Current_Name_Struct!" "!counter_prop!"

            if "%%b"=="" call "%~dp0ErrorProtocol.bat" "#007" "!Current_Name_Struct!" "!counter_prop!"

            if defined del_curr_struct del "!Current_DB_Struct!"
            (
                echo set "!Current_Name_Struct!_TypeData_Prop!counter_prop!=%%a"
                echo set "!Current_Name_Struct!_PropertyName_Prop!counter_prop!=%%b"

            ) >> !Current_DB_Struct!
        )
    )
)
shift
goto :Struct_Loop

:Struct_Done

set /a "TotalProperties_Struct_X=!counter_prop!"

(
    echo set "TotalProperties-Struct-!Current_Name_Struct!=!counter_prop!"
    echo exit /b
) >> !Current_DB_Struct!

endlocal
exit /b


:Capcha:Type_INT

set "flag_1="

for /f "delims=1,2,3,4,5,6,7,8,9,0" %%v in ("%current_Value%") do set "flag_1=1"

if defined flag_1 (
    call "%~dp0ErrorProtocol.bat" "#003" "%current_Value%" "%Current_Name_Object%" "%Current_Name_Struct%"
)

exit /b

:Record_Single_Property

call set "current_TypeData=%%%~1_TypeData_Prop%~2%%"
call set "current_PropertyName=%%%~1_PropertyName_Prop%~2%%"

if "%current_TypeData%"=="int" call :Capcha:Type_INT "%current_Value%" "%Current_Name_Object%" "%Current_Name_Struct%"
if "%current_TypeData%"=="str" rem -

set "%~1.%Current_Name_Object%.%current_PropertyName%=%current_Value%"

exit /b

:InitVar

set "Current_Name_Struct=%~2"
set "Current_Name_Object=%~3"

set "Current_DB_Struct=%~dp0DataBase-Structs\DataBase-Struct-%Current_Name_Struct%.meta"

if not exist "%Current_DB_Struct%" (
    call "%~dp0ErrorProtocol.bat" "#002" "%Current_Name_Object%" "%Current_Name_Struct%"
)

for /f "usebackq delims=" %%i in ("%Current_DB_Struct%") do (
    if "%%i"=="exit /b" (
        rem -
    ) else (
        %%i
    )
)

call set "current_TotalProperties-Struct=%%TotalProperties-Struct-%Current_Name_Struct%%%"

set "counter_prop=0"

:InitVar_Loop

set "current_Value=%~4"
set /a "counter_prop+=1"

if "!current_Value!"=="" goto :Initvar_Done
if %counter_prop% GTR %current_TotalProperties-Struct% call "%~dp0ErrorProtocol.bat" "#009" "%Current_Name_Object%" "%Current_Name_Struct%"

call :Record_Single_Property "%Current_Name_Struct%" "%counter_prop%" "%current_Value%"

shift
goto :InitVar_Loop


:Initvar_Done

exit /b



:Resolve_Namespace_Record

for /f "delims=" %%v in ('set "%~1." 2^>nul ^| findstr /b /c:"%~1."') do set "have_entity=1"

if not "%have_entity%"=="1" call "%~dp0ErrorProtocol.bat" "#005" "%~1"


for /f "delims=" %%i in ('set "%~1." 2^>nul ^| findstr /b /c:"%~1."') do (
    for /f "delims== tokens=1,2" %%a in ("%%i") do (
                
        set "%Path_Class%.%%a=%%b"
    )
)

exit /b

:Resolve_Namespace

set "Path_Class=%~2"
set "counter_prop=0"

:Resolve_Namespace_Loop

set "Current_Name_Struct=%~3"
set /a "counter_prop+=1"

if "%Current_Name_Struct%"=="" goto :Resolve_Namespace_Done

set "Current_DB_Struct=%~dp0DataBase-Structs\DataBase-Struct-%Current_Name_Struct%.meta"

if not exist "%Current_DB_Struct%" call "%~dp0ErrorProtocol.bat" "#004" "%Current_Name_Struct%"

call :Resolve_Namespace_Record "%Current_Name_Struct%"

shift
goto :Resolve_Namespace_Loop

:Resolve_Namespace_Done

exit /b
