@echo off 
::     =================================
::       S   E   T   T   I   N   G   S   
::     =================================

set "ENGINE_ROOT_DIR=Struct Utility" 

echo "%~dp0" | findstr /i /c:"%ENGINE_ROOT_DIR%" >nul

if %errorlevel%==0 (
    set "ES-engine=call "%~dp0engine.bat""
) else (
    set "ES-engine=call "%~dp0Struct Utility\engine.bat""
)

:: =========================================
::   I N S T R U C T I O N   F O R   U S E
:: =========================================

:: How to create a new Struct:

:: %ES-engine% struct "OptMode-true/false" "ClassName" "Type:Property1" "Type:Property2" ... (and so on)
:: --------------------------------------
:: Property Format: DataType:PropertyName

:: Example:
:: %ES-engine% struct "resources" "int:count" "str:name"

:: How to initialize a new Entity:

:: %ES-engine% new "ClassName" "EntityName" "Value1" "Value2" ... (and so on)

:: Example:
:: %ES-engine% new "resources" "wood" "50" "Pine Wood"
:: Usage: %resources.wood.name% is Pine Wood

:: How to create a namespace:

:: %ES-engine% namespace "Name Namespace" "Name class" ... (and so on)

:: Example:
:: ES-engine% namespace "items" "resources"
:: Usage: %items.resources.wood.name%
chcp 65001 >nul

setlocal enabledelayedexpansion
!ES-engine! struct "OptMode-f" "item" "int:price" "str:name"

!ES-engine! new "item" "iron" "300" "Strong Iron"
:: call "!ES-engine!" :resolve_namespace "amespace" "test1" 
:: call "!ES-engine!" :resolve_namespace "MODELS" "ITEMS"
echo !item.iron.name!

pause

