@echo off
chcp 65001 >nul
set "Version_Utility=1.0"

findstr /b /i ":Protocol_%~1" "%~f0" >nul 2>&1

if %errorlevel%==1 (
    
    cls
    echo.
    echo     ERROR ErrorProtocol.bat // %time:~0,5% // v%Version_Utility%
    echo.
    echo     Incorrect Syntax: Error protocol "%~1" has not been initialized.
    echo.

    pause
    exit
)


cls
echo.
echo     ERROR engine.bat // %time:~0,5% // v%Version_Utility%
echo.

call :Protocol_%~1 "%~2" "%~3" "%~4" 2^>nul

echo.

pause
exit

:Protocol_#001
echo     Incorrect Syntax: The engine mode is specified incorrectly.
exit /b

:Protocol_#002
echo     Incorrect Syntax: ^> Type Mismatch: Entity "%~1" class conflicts with the original class name. (Incorrect Name Class: %~2)
exit /b

:Protocol_#003
echo     Incorrect Syntax: Invalid argument value "%~1". Expected type "int" (Type conflict for Entity "%~2" of Class "%~3").
exit /b

:Protocol_#004
echo     Incorrect Syntax: Class with this name: "%~1" does not exist.
exit /b

:Protocol_#005
echo     Incorrect Syntax: Class "%~1" has no initialized entities.
exit /b

:Protocol_#006
echo     Incorrect Syntax: ^> Type Mismatch: Class "%~1" (Property #%~2) conflicts with the expected data type.
exit /b

:Protocol_#007
echo     Incorrect Syntax: Class "%~1" ^> Property definition #%~2 contains an empty identifier.
exit /b

:Protocol_#008
echo     Incorrect Syntax: Class name "%~1" contains invalid characters [%%,\,:,^^!].
exit /b

:Protocol_#009
echo     Incorrect Syntax: ^> Argument Error: The number of property values for Entity "%~1" of Class "%~2" exceeds the maximum allowed property count for this class.
exit /b